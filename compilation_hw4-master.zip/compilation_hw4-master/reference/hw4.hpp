#ifndef HW4_236360
#define HW4_236360

#include <string>

typedef struct {
	std::string type;
	std::string id;
} STYPE;

#define YYSTYPE STYPE

#endif
