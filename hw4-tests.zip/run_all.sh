make
cd all_tests
echo "Running Test 1:"
./run_my_tests.sh
echo "Running Test 2:"
./run_test.sh
echo "Running Test 3:"
./run_tests.sh
echo "Running Test 4:"
./run_ts.sh
echo "----------------------------------------------------------------"
echo "FINISHED ALL TESTS"
cd ..
